import { initializeApp } from "https://www.gstatic.com/firebasejs/11.6.0/firebase-app.js";
import { getFirestore, doc, getDoc, updateDoc, arrayUnion, setDoc } from "https://www.gstatic.com/firebasejs/11.6.0/firebase-firestore.js";

const firebaseConfig = {
  apiKey: "AIzaSyBhuMXs-LfWGGV44GUAmwe4xZ1NnBQ6Mt0",
  authDomain: "todolist-89067.firebaseapp.com",
  projectId: "todolist-89067",
  storageBucket: "todolist-89067.firebasestorage.app",
  messagingSenderId: "692613702446",
  appId: "1:692613702446:web:6b932720e0ac4ba332d0bf"
};

const app = initializeApp(firebaseConfig);
const db = getFirestore(app);

export { db, doc, getDoc, updateDoc, arrayUnion, setDoc };
