// Fungsi untuk menampilkan feedback sementara
function showFeedback(message, duration = 3000) {
    const feedbackMessage = document.getElementById('feedback-message');
    const feedbackText = document.getElementById('feedback-text');
    if (feedbackMessage && feedbackText) {
        feedbackText.textContent = message;
        feedbackMessage.style.display = 'block';
        setTimeout(() => {
            feedbackMessage.style.display = 'none';
        }, duration);
    } else {
        console.warn('Feedback message element not found');
    }
}

export function setupInstallPrompt() {
    let deferredPrompt = null;
    const installPrompt = document.getElementById('install-prompt');
    const dismissInstallBtn = document.getElementById('dismiss-install');
    const installConfirm = document.getElementById('install-confirm');
    const installNowBtn = document.getElementById('install-now');
    const installLaterBtn = document.getElementById('install-later');

    // Pengecekan elemen DOM
    if (!installPrompt || !dismissInstallBtn || !installConfirm || !installNowBtn || !installLaterBtn) {
        console.error('One or more install prompt elements not found in DOM');
        return;
    }

    // Ambil status dari localStorage
    const hasSeenPrompt = localStorage.getItem('has_seen_install_prompt');
    const hasSeenConfirm = localStorage.getItem('has_seen_install_confirm');

    window.addEventListener('beforeinstallprompt', (e) => {
        console.log('beforeinstallprompt fired');
        e.preventDefault();
        deferredPrompt = e;
    });

    if (!hasSeenPrompt) {
        setTimeout(() => {
            installPrompt.classList.add('visible');
            localStorage.setItem('has_seen_install_prompt', 'true');
        }, 3000);
    }

    dismissInstallBtn.addEventListener('click', () => {
        installPrompt.classList.remove('visible');
        if (!hasSeenConfirm && deferredPrompt) {
            installConfirm.classList.add('visible');
            localStorage.setItem('has_seen_install_confirm', 'true');
        }
    });

    installNowBtn.addEventListener('click', async () => {
        if (deferredPrompt) {
            console.log('Triggering install prompt');
            deferredPrompt.prompt();
            const { outcome } = await deferredPrompt.userChoice;
            console.log('Install prompt outcome:', outcome);
            if (outcome === 'accepted') {
                showFeedback('App installed successfully!');
            } else {
                showFeedback('App installation cancelled.');
            }
            deferredPrompt = null;
        }
        installConfirm.classList.remove('visible');
    });

    installLaterBtn.addEventListener('click', () => {
        console.log('User dismissed install confirm');
        showFeedback('You can install the app later from settings.');
        installConfirm.classList.remove('visible');
    });

    // Reset prompt setelah 30 hari (opsional)
    const lastPromptTime = localStorage.getItem('last_prompt_time');
    const thirtyDaysInMs = 30 * 24 * 60 * 60 * 1000;
    if (lastPromptTime && (Date.now() - parseInt(lastPromptTime) > thirtyDaysInMs)) {
        localStorage.removeItem('has_seen_install_prompt');
        localStorage.removeItem('has_seen_install_confirm');
        localStorage.setItem('last_prompt_time', Date.now().toString());
    } else if (!lastPromptTime) {
        localStorage.setItem('last_prompt_time', Date.now().toString());
    }
}