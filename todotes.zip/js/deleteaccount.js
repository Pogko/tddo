import { db, auth, doc, deleteDoc } from './firebase.js';

// Gunakan variabel lingkungan untuk BASE_PATH, default ke '/' jika tidak ada
const BASE_PATH = process.env.BASE_PATH || '/';

export async function deleteAccount(identifier) {
    console.log("Attempting to delete account with identifier:", identifier);

    if (!confirm('Are you sure you want to delete your account and all tasks? This action cannot be undone.')) {
        console.log("Account deletion cancelled by user");
        return;
    }

    try {
        let userDocRef;
        const user = auth.currentUser;

        if (user && user.uid === identifier) {
            // Jika menggunakan Firebase Authentication
            userDocRef = doc(db, "users", user.uid);
            console.log("Deleting user document in Firestore with UID...");
            await deleteDoc(userDocRef);

            console.log("Deleting user from Firebase Authentication...");
            await user.delete();

            // Bersihkan local storage
            localStorage.removeItem(`tasks_${user.uid}`);
        } else {
            // Jika menggunakan sistem lama (encodedUsername)
            userDocRef = doc(db, "users", identifier);
            console.log("Deleting user document in Firestore with encodedUsername...");
            await deleteDoc(userDocRef);

            // Bersihkan local storage
            localStorage.removeItem(`tasks_${identifier}`);
        }

        localStorage.removeItem('todo_username');
        localStorage.removeItem('todo_username_fallback');
        localStorage.removeItem('todo_name');
        localStorage.removeItem('todo_theme');
        console.log("Cleared local storage");

        // Logout pengguna (jika ada)
        if (auth.currentUser) {
            console.log("Logging out user...");
            await auth.signOut();
        }

        console.log("Account deleted successfully");
        alert('Your account has been deleted.');
        window.location.href = `${BASE_PATH}index.html`;
    } catch (error) {
        console.error("Error deleting account:", error);
        if (error.code === 'auth/requires-recent-login') {
            alert('This operation requires recent authentication. Please log out and log in again, then try deleting your account.');
        } else {
            alert('Failed to delete account. Please try again.');
        }
    }
}