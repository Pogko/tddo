import { auth, db, doc, getDoc, setDoc } from './firebase.js';
import { deleteAccount } from './deleteAccount.js'; // Impor fungsi deleteAccount

// Gunakan variabel lingkungan untuk BASE_PATH, default ke '/' jika tidak ada
const BASE_PATH = process.env.BASE_PATH || '/';

export function setupLogin() {
    const landingButtons = document.getElementById('landing-buttons');
    const createUsernameForm = document.getElementById('create-username-form');
    const viewUsernameForm = document.getElementById('view-username-form');
    const deleteAccountForm = document.getElementById('delete-account-form');
    const deleteConfirmPopup = document.getElementById('delete-confirm-popup');
    
    const createListBtn = document.getElementById('create-list-btn');
    const viewListBtn = document.getElementById('view-list-btn');
    const deleteAccountBtn = document.getElementById('delete-account-btn');
    const saveUsernameBtn = document.getElementById('save-username-btn');
    const cancelUsernameBtn = document.getElementById('cancel-username-btn');
    const loadTasksBtn = document.getElementById('load-tasks-btn');
    const cancelViewBtn = document.getElementById('cancel-view-btn');
    const confirmDeleteBtn = document.getElementById('confirm-delete-btn');
    const cancelDeleteBtn = document.getElementById('cancel-delete-btn');
    const finalDeleteBtn = document.getElementById('final-delete-btn');
    const cancelConfirmDeleteBtn = document.getElementById('cancel-confirm-delete-btn');
    
    const nameInput = document.getElementById('name');
    const newUsernameInput = document.getElementById('new-username');
    const newPasswordInput = document.getElementById('new-password');
    const existingUsernameInput = document.getElementById('existing-username');
    const existingPasswordInput = document.getElementById('existing-password');
    const deleteUsernameInput = document.getElementById('delete-username');
    const deletePasswordInput = document.getElementById('delete-password');
    const recentTasks = document.getElementById('recent-tasks');

    function encodeUsername(username) {
        return btoa(encodeURIComponent(username));
    }

    function applySavedTheme() {
        const savedTheme = localStorage.getItem('todo_theme');
        if (savedTheme) {
            console.log("Applying saved theme:", savedTheme);
            document.body.className = savedTheme === 'light' ? '' : `${savedTheme}-mode`;
        }
    }

    applySavedTheme();

    createListBtn.addEventListener('click', function() {
        landingButtons.style.display = 'none';
        createUsernameForm.classList.add('visible');
        newUsernameInput.focus();
    });

    viewListBtn.addEventListener('click', function() {
        landingButtons.style.display = 'none';
        viewUsernameForm.classList.add('visible');
        existingUsernameInput.focus();
    });

    deleteAccountBtn.addEventListener('click', function() {
        landingButtons.style.display = 'none';
        deleteAccountForm.classList.add('visible');
        deleteUsernameInput.focus();
    });

    function resetForms() {
        landingButtons.style.display = 'flex';
        createUsernameForm.classList.remove('visible');
        viewUsernameForm.classList.remove('visible');
        deleteAccountForm.classList.remove('visible');
        deleteConfirmPopup.style.display = 'none';
        nameInput.value = '';
        newUsernameInput.value = '';
        newPasswordInput.value = '';
        existingUsernameInput.value = '';
        existingPasswordInput.value = '';
        deleteUsernameInput.value = '';
        deletePasswordInput.value = '';
    }

    cancelUsernameBtn.addEventListener('click', resetForms);
    cancelViewBtn.addEventListener('click', resetForms);
    cancelDeleteBtn.addEventListener('click', resetForms);
    cancelConfirmDeleteBtn.addEventListener('click', resetForms);

    saveUsernameBtn.addEventListener('click', async function() {
        const name = nameInput.value.trim();
        const username = newUsernameInput.value.trim();
        const password = newPasswordInput.value.trim();
        if (!name || !username || !password) {
            alert('Please fill in all fields');
            return;
        }

        try {
            const encodedUsername = encodeUsername(username);
            const userDocRef = doc(db, "users", encodedUsername);
            
            const userDoc = await getDoc(userDocRef);
            if (userDoc.exists()) {
                alert('Username already exists. Please choose another or view your existing list.');
                return;
            }

            await setDoc(userDocRef, {
                name,
                username,
                password,
                tasks: [],
                createdAt: new Date()
            });

            sessionStorage.setItem('todo_username', encodedUsername);
            localStorage.setItem('todo_username_fallback', encodedUsername);
            localStorage.setItem('todo_name', name);
            window.location.href = `${BASE_PATH}app.html`;
        } catch (error) {
            console.error("Error creating user: ", error);
            alert('An error occurred. Please try again.');
        }
    });

    loadTasksBtn.addEventListener('click', async function() {
        const username = existingUsernameInput.value.trim();
        const password = existingPasswordInput.value.trim();
        if (!username || !password) {
            alert('Please fill in all fields');
            return;
        }

        try {
            const encodedUsername = encodeUsername(username);
            const userDocRef = doc(db, "users", encodedUsername);
            
            const userDoc = await getDoc(userDocRef);
            if (!userDoc.exists()) {
                alert('Username not found. Please check your username or create a new list.');
                return;
            }

            const userData = userDoc.data();
            if (userData.password !== password) {
                alert('Incorrect password. Please try again.');
                return;
            }

            sessionStorage.setItem('todo_username', encodedUsername);
            localStorage.setItem('todo_username_fallback', encodedUsername);
            localStorage.setItem('todo_name', userData.name);
            window.location.href = `${BASE_PATH}app.html`;
        } catch (error) {
            console.error("Error loading user: ", error);
            alert('An error occurred. Please try again.');
        }
    });

    confirmDeleteBtn.addEventListener('click', async () => {
        const username = deleteUsernameInput.value.trim();
        const password = deletePasswordInput.value.trim();
        if (!username || !password) {
            alert('Please enter your username and password');
            return;
        }

        try {
            const encodedUsername = encodeUsername(username);
            const userDocRef = doc(db, "users", encodedUsername);
            const userDoc = await getDoc(userDocRef);

            if (!userDoc.exists()) {
                alert('Username not found.');
                return;
            }

            const userData = userDoc.data();
            if (userData.password !== password) {
                alert('Incorrect password. Please try again.');
                return;
            }

            // Show recent tasks in popup
            const tasks = userData.tasks || [];
            recentTasks.innerHTML = '<strong>Recent Tasks:</strong><ul>' + 
                tasks.slice(0, 5).map(task => `<li>${task.title}</li>`).join('') + 
                '</ul>';
            if (tasks.length === 0) {
                recentTasks.innerHTML = '<p>No tasks found.</p>';
            }

            deleteAccountForm.classList.remove('visible');
            deleteConfirmPopup.style.display = 'flex';
        } catch (error) {
            console.error("Error verifying user for deletion:", error);
            alert('An error occurred. Please try again.');
        }
    });

    finalDeleteBtn.addEventListener('click', async () => {
        const username = deleteUsernameInput.value.trim();
        try {
            const encodedUsername = encodeUsername(username);
            const user = auth.currentUser;
            if (user) {
                await deleteAccount(user.uid);
            } else {
                await deleteAccount(encodedUsername);
            }
            resetForms(); // Reset form setelah penghapusan
        } catch (error) {
            console.error("Error deleting account:", error);
            alert('Failed to delete account. Please try again.');
        }
    });

    newUsernameInput.addEventListener('keypress', function(e) {
        if (e.key === 'Enter') {
            saveUsernameBtn.click();
        }
    });

    existingUsernameInput.addEventListener('keypress', function(e) {
        if (e.key === 'Enter') {
            loadTasksBtn.click();
        }
    });

    deleteUsernameInput.addEventListener('keypress', function(e) {
        if (e.key === 'Enter') {
            confirmDeleteBtn.click();
        }
    });
}