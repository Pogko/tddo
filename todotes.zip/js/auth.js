import { auth, db } from './firebase.js'; // Impor Firebase
import { onAuthStateChanged, signOut } from 'firebase/auth';
import { doc, getDoc } from 'firebase/firestore';
import { deleteAccount } from './deleteAccount.js'; // Impor untuk integrasi penghapusan akun

// Gunakan variabel lingkungan untuk BASE_PATH, default ke '/' jika tidak ada
const BASE_PATH = process.env.BASE_PATH || '/';

// Fungsi untuk menampilkan feedback sementara
function showFeedback(message, duration = 3000) {
    const feedbackMessage = document.getElementById('feedback-message');
    const feedbackText = document.getElementById('feedback-text');
    if (feedbackMessage && feedbackText) {
        feedbackText.textContent = message;
        feedbackMessage.style.display = 'block';
        setTimeout(() => {
            feedbackMessage.style.display = 'none';
        }, duration);
    } else {
        console.warn('Feedback message element not found');
    }
}

export function handleAuth() {
    return new Promise((resolve, reject) => {
        onAuthStateChanged(auth, async (user) => {
            if (user) {
                try {
                    // Ambil data pengguna dari Firestore
                    const userDoc = await getDoc(doc(db, "users", user.uid));
                    if (userDoc.exists()) {
                        const userData = userDoc.data();
                        const username = userData.username;
                        const name = userData.name || username; // Gunakan username sebagai fallback untuk name
                        const encodedUsername = btoa(encodeURIComponent(username)); // Kompatibel dengan sistem asli
                        const uid = user.uid;
                        console.log("User authenticated:", username, "with UID:", uid);
                        resolve({ username, name, encodedUsername, uid });
                    } else {
                        console.error("User data not found in Firestore for UID:", user.uid);
                        showFeedback('User data not found. Redirecting to login.');
                        window.location.href = `${BASE_PATH}index.html`;
                        resolve(null);
                    }
                } catch (error) {
                    console.error("Error fetching user data:", error);
                    showFeedback('Error loading user data. Please try again.');
                    reject(error);
                }
            } else {
                console.log("No user authenticated, handling offline or redirecting");
                if (!navigator.onLine) {
                    const offlineLogin = document.getElementById('offline-login');
                    const container = document.querySelector('.container');
                    if (offlineLogin && container) {
                        offlineLogin.style.display = 'block';
                        container.style.display = 'none';
                        showFeedback('Offline mode: Please connect to login.');
                    } else {
                        console.error("Offline login or container element not found");
                    }
                } else {
                    showFeedback('No user logged in. Redirecting to login.');
                    window.location.href = `${BASE_PATH}index.html`;
                }
                resolve(null);
            }
        }, (error) => {
            console.error("Auth state error:", error);
            showFeedback('Authentication error. Please try again.');
            reject(error);
        });
    });
}

export function setupLogout() {
    const logoutBtn = document.getElementById('logout-btn');
    if (logoutBtn) {
        logoutBtn.addEventListener('click', async () => {
            console.log("Logging out...");
            try {
                // Panggil deleteAccount untuk menghapus data pengguna dari Firestore
                const uid = auth.currentUser ? auth.currentUser.uid : null;
                if (uid) {
                    await deleteAccount(uid);
                    console.log("User data deleted from Firestore");
                }
                await signOut(auth); // Logout dari Firebase
                sessionStorage.removeItem('todo_username');
                localStorage.removeItem('todo_username_fallback');
                localStorage.removeItem('todo_name');
                showFeedback('Logged out successfully.');
                window.location.href = `${BASE_PATH}index.html`;
            } catch (error) {
                console.error("Logout error:", error);
                showFeedback('Failed to log out. Please try again.');
            }
        });
    } else {
        console.error("Logout button not found");
    }
}