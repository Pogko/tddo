// Gunakan variabel lingkungan untuk BASE_PATH, default ke '/' jika tidak ada
const BASE_PATH = process.env.BASE_PATH || '/';

// Fungsi untuk menampilkan feedback sementara
function showFeedback(message, duration = 3000) {
    const feedbackMessage = document.getElementById('feedback-message');
    const feedbackText = document.getElementById('feedback-text');
    if (feedbackMessage && feedbackText) {
        feedbackText.textContent = message;
        feedbackMessage.style.display = 'block';
        setTimeout(() => {
            feedbackMessage.style.display = 'none';
        }, duration);
    } else {
        console.warn('Feedback message element not found');
    }
}

export function registerServiceWorker() {
    if ('serviceWorker' in navigator) {
        window.addEventListener('load', () => {
            navigator.serviceWorker.register(`${BASE_PATH}sw.js`)
                .then(reg => {
                    console.log('Service Worker registered:', reg);
                    showFeedback('Service Worker registered successfully.');
                })
                .catch(err => {
                    console.error('Service Worker registration failed:', err);
                    showFeedback('Failed to register Service Worker. Some features may not work offline.');
                });
        });
    } else {
        console.warn('Service Worker not supported in this browser');
        showFeedback('Service Worker not supported. Offline features may be limited.');
    }
}