import { registerServiceWorker } from './service-worker.js';
import { setupInstallPrompt } from './install-prompt.js';
import { handleAuth, setupLogout } from './auth.js';
import { loadTasks } from './tasks.js';
import { setupUI } from './ui.js';
import { deleteAccount } from './deleteAccount.js';

// Gunakan variabel lingkungan untuk BASE_PATH, default ke '/' jika tidak ada
const BASE_PATH = process.env.BASE_PATH || '/';

// Fungsi untuk menampilkan feedback sementara
function showFeedback(message, duration = 3000) {
    const feedbackMessage = document.getElementById('feedback-message');
    const feedbackText = document.getElementById('feedback-text');
    if (feedbackMessage && feedbackText) {
        feedbackText.textContent = message;
        feedbackMessage.style.display = 'block';
        setTimeout(() => {
            feedbackMessage.style.display = 'none';
        }, duration);
    } else {
        console.warn('Feedback message element not found');
    }
}

document.addEventListener('DOMContentLoaded', async function() {
    console.log("App initializing...");
    try {
        registerServiceWorker();
        setupInstallPrompt();

        const authData = await handleAuth();
        if (!authData) {
            console.log("Authentication failed, redirecting to index.html");
            window.location.href = `${BASE_PATH}index.html`;
            return;
        }

        const { username, encodedUsername, name, uid } = authData;
        console.log("Setting up UI and logout for user:", username);
        setupLogout();

        const { toggleAddTaskForm, toggleEditForm, toggleSettingsPanel, showCelebration, renderTasks } = setupUI(uid, username, name, animateAddTask);

        // Event listener untuk tombol logout (digunakan untuk logout dan penghapusan akun)
        const logoutBtn = document.getElementById('logout-btn');
        if (logoutBtn) {
            logoutBtn.addEventListener('click', async () => {
                console.log("Logout button clicked for user:", uid);
                try {
                    await deleteAccount(uid); // Panggil deleteAccount untuk logout dan pembersihan
                    showFeedback('Logged out successfully.');
                    window.location.href = `${BASE_PATH}index.html`;
                } catch (error) {
                    console.error('Error during logout:', error);
                    showFeedback('Failed to log out. Please try again.');
                }
            });
        } else {
            console.warn("Logout button not found in DOM");
        }

        // Event listener untuk tugas (checkbox, edit, delete)
        const taskList = document.getElementById('task-list');
        if (taskList) {
            taskList.addEventListener('click', async (e) => {
                const target = e.target;
                const taskId = target.closest('.task-item')?.dataset.id;

                if (target.classList.contains('task-checkbox')) {
                    await toggleTaskComplete(taskId, uid, showCelebration);
                } else if (target.closest('.edit-btn')) {
                    const task = tasks.find(t => t.id === taskId); // Asumsi tasks global dari tasks.js
                    if (task) {
                        toggleEditForm(true, task);
                    }
                } else if (target.closest('.delete-btn')) {
                    if (confirm('Are you sure you want to delete this task?')) {
                        await deleteTask(taskId, uid);
                    }
                }
            });
        } else {
            console.warn("Task list not found in DOM");
        }

        console.log("Loading tasks...");
        await loadTasks(uid, renderTasks);
        console.log("App initialization complete");
    } catch (error) {
        console.error("Error during app initialization:", error);
        showFeedback('Failed to initialize app. Please try again.');
    }

    function animateAddTask() {
        console.log("Animating add task...");
        const taskList = document.getElementById('task-list');
        if (taskList) {
            taskList.classList.add('task-added');
            setTimeout(() => {
                taskList.classList.remove('task-added');
            }, 1000);
        } else {
            console.error("Task list not found for animation");
        }
    }
});