// Gunakan variabel lingkungan untuk BASE_PATH, default ke '/' jika tidak ada
const BASE_PATH = process.env.BASE_PATH || '/';

// Nama cache
const CACHE_NAME = 'todo-cache-v1';

// Daftar sumber daya yang akan di-cache
const urlsToCache = [
    `${BASE_PATH}index.html`,
    `${BASE_PATH}app.html`,
    `${BASE_PATH}css/app.css`,
    `${BASE_PATH}css/index.css`,
    `${BASE_PATH}js/main.js`,
    `${BASE_PATH}js/ui.js`,
    `${BASE_PATH}js/tasks.js`,
    `${BASE_PATH}js/auth.js`,
    `${BASE_PATH}js/deleteAccount.js`,
    `${BASE_PATH}js/service-worker.js`,
    `${BASE_PATH}js/install-prompt.js`,
    `${BASE_PATH}manifest.json`,
    'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css',
    'https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700&display=swap',
    'https://www.gstatic.com/firebasejs/11.6.0/firebase-app-compat.js',
    'https://www.gstatic.com/firebasejs/11.6.0/firebase-auth-compat.js',
    'https://www.gstatic.com/firebasejs/11.6.0/firebase-firestore-compat.js'
];

self.addEventListener('install', event => {
    console.log('Service Worker: Installing...');
    event.waitUntil(
        caches.open(CACHE_NAME)
            .then(cache => {
                console.log('Service Worker: Caching files');
                return cache.addAll(urlsToCache);
            })
            .catch(error => {
                console.error('Service Worker: Cache failed during install:', error);
            })
    );
});

self.addEventListener('fetch', event => {
    const requestUrl = new URL(event.request.url);

    // Strategi caching berdasarkan jenis sumber daya
    if (requestUrl.origin === location.origin) {
        // Untuk sumber daya lokal, gunakan "cache first"
        event.respondWith(
            caches.match(event.request)
                .then(response => {
                    if (response) {
                        console.log('Service Worker: Found in cache:', requestUrl);
                        return response;
                    }
                    console.log('Service Worker: Fetching from network:', requestUrl);
                    return fetch(event.request)
                        .then(networkResponse => {
                            if (!networkResponse || networkResponse.status !== 200) {
                                return networkResponse;
                            }
                            // Cache respons baru
                            return caches.open(CACHE_NAME).then(cache => {
                                cache.put(event.request, networkResponse.clone());
                                return networkResponse;
                            });
                        })
                        .catch(error => {
                            console.error('Service Worker: Fetch failed:', error);
                            throw error;
                        });
                })
        );
    } else {
        // Untuk sumber daya eksternal (Font Awesome, Google Fonts, Firebase), gunakan "stale-while-revalidate"
        event.respondWith(
            caches.open(CACHE_NAME).then(cache => {
                return cache.match(event.request).then(cachedResponse => {
                    const fetchPromise = fetch(event.request)
                        .then(networkResponse => {
                            cache.put(event.request, networkResponse.clone());
                            return networkResponse;
                        })
                        .catch(error => {
                            console.error('Service Worker: Fetch failed for external resource:', error);
                            throw error;
                        });
                    return cachedResponse || fetchPromise;
                });
            })
        );
    }
});

self.addEventListener('activate', event => {
    console.log('Service Worker: Activating...');
    const cacheWhitelist = [CACHE_NAME];
    event.waitUntil(
        caches.keys().then(cacheNames => {
            return Promise.all(
                cacheNames.map(cacheName => {
                    if (!cacheWhitelist.includes(cacheName)) {
                        console.log('Service Worker: Deleting old cache:', cacheName);
                        return caches.delete(cacheName);
                    }
                })
            );
        })
    );
});